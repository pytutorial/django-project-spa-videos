#app/urls.py
from django.urls import path
from .views import *
from rest_framework.routers import DefaultRouter

urlpatterns = [
    path('hello', hello),
    path('search-product', search_product),
    path('order-product/<pk>', order_product),
]

router = DefaultRouter()
router.register('category', CategoryViewSet)
urlpatterns += router.urls

router = DefaultRouter()
router.register('product', ProductViewSet)
urlpatterns += router.urls