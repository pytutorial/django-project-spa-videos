from datetime import datetime
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet
from rest_framework.serializers import ModelSerializer, CharField, IntegerField, DateTimeField

from .models import *

class CategorySerializer(ModelSerializer):
    class Meta:
        model = Category
        fields = '__all__'

class CategoryViewSet(ModelViewSet):
    serializer_class = CategorySerializer
    queryset = Category.objects.all()

class ProductSerializer(ModelSerializer):
    class Meta:
        model = Product
        fields = '__all__'

class ProductViewSet(ModelViewSet):
    serializer_class = ProductSerializer
    queryset = Product.objects.all()

@api_view(['GET'])
def hello(request):
    return Response({'message': 'Hello'})

@api_view(['GET'])
def search_product(request):
    PAGE_SIZE = 5
    price_ranges = [
        {'max': 10},  # 0..10
        {'min': 10, 'max': 20}, # 10..20
        {'min': 20}             # 20+
    ]

    data = request.GET
    start = int(data.get('start', 0))
    count = int(data.get('count', PAGE_SIZE))
    categoryId = data.get('categoryId')
    priceRangeId = data.get('priceRangeId')
    keyword = data.get('keyword', '')

    product_list = Product.objects.filter(name__icontains=keyword)
    if categoryId:
        product_list = product_list.filter(category__id=categoryId)

    if priceRangeId and priceRangeId.isdigit():
        price_range = price_ranges[int(priceRangeId)-1]
        price_min = price_range.get('min')
        price_max = price_range.get('max')

        if price_min:
            product_list = product_list.filter(price__gte=price_min * 1000000)

        if price_max:
            product_list = product_list.filter(price__lte=price_max * 1000000)

    total = product_list.count()
    items = product_list[start:start+count]
    data = ProductSerializer(items, many=True).data
    return Response({'total': total, 'items': data})

class OrderSerializer(ModelSerializer):
    class Meta:
        model = Order
        exclude = ['product']

    product_name = CharField(read_only=True, source='product.name')
    price_unit = IntegerField(read_only=True)
    order_date = DateTimeField(read_only=True, format='%d/%m/%Y %H:%M:%S')
    deliver_date = DateTimeField(read_only=True, format='%d/%m/%Y %H:%M:%S')
    status = IntegerField(read_only=True)


@api_view(['POST'])
def order_product(request, pk):
    product = Product.objects.get(pk=pk)
    serializer = OrderSerializer(data=request.data)
    if serializer.is_valid():
        order = Order()
        order.product = product
        order.price_unit = product.price
        order.qty = request.data.get('qty')
        order.customer_name = request.data.get('customer_name')
        order.customer_phone = request.data.get('customer_phone')
        order.customer_address = request.data.get('customer_address')
        order.order_date = datetime.now()
        order.status = Order.Status.PENDING
        order.save()
        return Response({'success': True})
    else:
        return Response(serializer.errors, status=400)