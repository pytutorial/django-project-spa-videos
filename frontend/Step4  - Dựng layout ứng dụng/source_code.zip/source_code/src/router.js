import Vue from 'vue';
import VueRouter from 'vue-router';

import Page1 from '@/pages/Page1';
import Page2 from '@/pages/Page2';
import Page3 from '@/pages/Page3';

Vue.use(VueRouter);

const routes = [
    {
        path: '/',
        name: 'page1',
        component: Page1,
        meta: {page: 1},
    },
    {
        path: '/page-2',
        name: 'page2',
        component: Page2,
        meta: {page: 2},
    },
    {
        path: '/page-3',
        name: 'page3',
        component: Page3,
        meta: {page: 3},
    }
];
const router = new VueRouter({routes});
export default router;