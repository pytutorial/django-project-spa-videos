import Vue from 'vue';
import VueRouter from 'vue-router';

import Page1 from '@/pages/Page1';
import Page2 from '@/pages/Page2';
import Page3 from '@/pages/Page3';
import Login from './Login';

import CategoryList from '@/pages/staff/category/List';
import ProductList from '@/pages/staff/product/List';
import OrderList from '@/pages/staff/order/List';

Vue.use(VueRouter);

const routes = [
    {
        path: '/staff',
        name: 'categoryList',
        component: CategoryList,
        meta: {page: 1},
    },
    {
        path: '/staff/product',
        name: 'productList',
        component: ProductList,
        meta: {page: 2},
    },
    {
        path: '/staff/order',
        name: 'orderList',
        component: OrderList,
        meta: {page: 3},
    },
    {
        path: '/login',
        name: 'login',
        component: Login,
    },
    {
        path: '/',
        name: 'page1',
        component: Page1,
        meta: {page: 1},
    },
    {
        path: '/page-2',
        name: 'page2',
        component: Page2,
        meta: {page: 2},
    },
    {
        path: '/page-3',
        name: 'page3',
        component: Page3,
        meta: {page: 3},
    }
];
const router = new VueRouter({routes});
export default router;