<template>
    <div>
        Page 2
    </div>
</template>