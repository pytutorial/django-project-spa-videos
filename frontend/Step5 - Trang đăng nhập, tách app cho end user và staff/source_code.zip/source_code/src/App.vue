<template>
  <div>
    <Login v-if="$route.name=='login'"></Login>
    <AppStaff v-else-if="$route.path.startsWith('/staff')"></AppStaff>
    <AppEndUser v-else></AppEndUser>
  </div>
</template>

<script>
import Login from './Login';
import AppEndUser from './AppEndUser';
import AppStaff from './AppStaff';

export default {
  components: {
    Login,
    AppStaff,
    AppEndUser
  }
}
</script>