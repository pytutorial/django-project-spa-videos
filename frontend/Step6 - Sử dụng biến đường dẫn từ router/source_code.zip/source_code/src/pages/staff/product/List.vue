<template>
    <div>
        Danh sách sản phẩm
    </div>
</template>