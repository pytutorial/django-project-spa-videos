<template>
    <div>
        Danh sách nhóm sản phẩm
    </div>
</template>