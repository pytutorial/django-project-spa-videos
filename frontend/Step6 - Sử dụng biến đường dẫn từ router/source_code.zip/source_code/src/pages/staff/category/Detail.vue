<template>
    <div>
        Thông tin nhóm sản phẩm : {{categoryId}}
    </div>
</template>
<script>
export default {
    data: () => ({
        categoryId: null
    }),
    mounted: function() {
        this.categoryId = this.$route.params.id;
    }
}
</script>